package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.OrthographicCamera;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import static com.badlogic.gdx.scenes.scene2d.actions.Actions.delay;

public class MyGdxGame extends ApplicationAdapter {
	SpriteBatch batch;
	Texture img;
        private OrthographicCamera camera;
        private ladrom ladrom;
        
        
	
	@Override
	public void create () {
		batch = new SpriteBatch();
		img = new Texture("george.png");
	        
                camera = new OrthographicCamera();
                camera.setToOrtho(false,385,385);
                camera.update();
                
                ladrom = new ladrom(0,0);
                
 
        }

	@Override
	public void render () {
		Gdx.gl.glClearColor(1, 1, 1, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
                camera.update();
                batch.setProjectionMatrix(camera.combined);
		
                
                batch.begin();
		
               if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) {
                   ladrom.x=ladrom.x+20;
                   
                   ladrom.y=ladrom.y;
                   ladrom.render(batch);
                   
               }else{
               
                 ladrom.x=ladrom.x;
                 ladrom.y=ladrom.y;
                 ladrom.render(batch);
               }
                        
                        
                        
                
//batch.draw(img, 0, 0);
                
		batch.end();
                
                
                
	}
	
	@Override
	public void dispose () {
		batch.dispose();
		img.dispose();
	}
}
